package com.gathering.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceImple {

	@Autowired
	private UserInfoDAO userInfo;
	
	public void aa() {
		System.out.println(userInfo.getMember("aaaa").toString());
	}
	
	
}
