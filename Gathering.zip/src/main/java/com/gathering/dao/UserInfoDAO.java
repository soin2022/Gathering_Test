package com.gathering.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.gathering.dto.UserInfoVO;

@Repository
public class UserInfoDAO {
	@Autowired
	private SqlSessionTemplate mybatis;
	
	// 회원 상세정보 조회
	public UserInfoVO getMember(String user_id) {
		
			
		return mybatis.selectOne("memberMapper.getMember", user_id);
		
	}
	
	
			
	
}
