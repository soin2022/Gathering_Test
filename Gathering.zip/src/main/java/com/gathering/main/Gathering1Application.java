package com.gathering.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.gathering.dao.ServiceImple;


@SpringBootApplication
public class Gathering1Application {

	public static void main(String[] args) {
		SpringApplication.run(Gathering1Application.class, args);
		
		ServiceImple service = new ServiceImple();
		
		service.aa(); 
		
	}

}
