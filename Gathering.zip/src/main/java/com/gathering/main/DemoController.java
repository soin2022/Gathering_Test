package com.gathering.main;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DemoController {
	
    // http://localhost:8080/ 으로 접속 시
    @RequestMapping("/")
    public String welcome() {
        return "main";
    }
    
    // http://localhost:8080/test 로 접속 시
    @RequestMapping("/login")
    public String test() {
        return "member/login";
    }    
    
}